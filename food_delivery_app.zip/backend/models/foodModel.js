// MySQL Table: foods (id, name, price, image_url)
