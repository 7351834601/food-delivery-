# 🍔 Food Delivery App (Node.js + Flutter)

## How to Run
### Backend
1. Open terminal:
   ```bash
   cd backend
   npm install
   npm start
   ```

### Flutter App
1. Open another terminal:
   ```bash
   cd flutter_app
   flutter pub get
   flutter run
   ```
